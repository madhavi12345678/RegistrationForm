﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Registration_form.Models;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;

namespace Registration_form.Controllers
{
    public class HomeController : Controller
    {
        private readonly User_RegistrationFormContext _context;
        public string hobbies_s;

        public HomeController(User_RegistrationFormContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult RegistrationForm()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> RegistrationForm(User model , List<string> Hobbies)
        {
            
            foreach (var item in Hobbies)
            {
             hobbies_s = string.Join(",", Hobbies);
            }
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // Check if email already exists in table
            if (_context.User.Any(u => u.Email == model.Email))
            {
                ModelState.AddModelError("Email", "Email already exists.");
                return View(model);
            }
            // Send OTP to user's email address
            var otp = GenerateOTP();

            var user = new User
            {
                FirstName = model.FirstName,
                LastName = model.LastName,
                Email = model.Email,
                Password = model.Password,
                Mobile = model.Mobile,
                Gender = model.Gender,
                Hobbies = hobbies_s,
                Otp = otp ,
                EmailVerified = false
            };

            _context.User.Add(user);
             await _context.SaveChangesAsync();

            var senderEmail = new MailAddress("madhavipatel1030@gmail.com");
            var receiverEmail = new MailAddress(model.Email, "Receiver");
            var password = "provjqtdkzlkelxy";
            var sub = "Verify your Email";
      
            var verificationUrl = "https://localhost:7041/Home/VerifyEmail?email=" + HttpUtility.UrlEncode(model.Email) + "&otp=" + otp;
            var body = "Your OTP is here: " + otp + "\n\n" + "Please click the following link to verify your email address:\n" + verificationUrl;

            var smtp = new SmtpClient
            {
                Host = "smtp.gmail.com",
                Port = 587,
                EnableSsl = true,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential("madhavipatel1030@gmail.com", password)
            };
            using (var mess = new MailMessage(senderEmail, receiverEmail)
            {
                Subject = sub,
                Body = body
            })
            {
                smtp.Send(mess);
            }

            return RedirectToAction("ThankYou");
        }

        [HttpGet]
        public IActionResult VerifyEmail(string email, string otp)
        {
            var model = new VerifyEmailViewModel { Email = email, OTP = otp };
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> VerifyEmail(VerifyEmailViewModel model)
        {
            // Verify the email and OTP

            var user = await _context.User.SingleOrDefaultAsync(u => u.Email == model.Email && u.Otp == model.OTP);

            if (user == null)
            {
                return View("InvalidOTP");
            }

            //if email verified successfully then Update the user's email verification status
            user.EmailVerified = true;
            _context.SaveChanges();

            var userInfoModel = new User
            {
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                Mobile = user.Mobile,
                Gender = user.Gender,
                Hobbies = user.Hobbies,
                EmailVerified = user.EmailVerified
            };

            return View("EmailVerified", userInfoModel);
        }

        [HttpGet]
        public IActionResult InvalidOTP()
        {
            return View();
        }

        [HttpGet]
        public IActionResult EmailVerified()
        {
            return View();
        }

        public IActionResult ThankYou()
        {
            return View();
        }

        private string GenerateOTP()
        {
            //6 digit otp generate
            var random = new Random();
            return random.Next(100000, 999999).ToString();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}