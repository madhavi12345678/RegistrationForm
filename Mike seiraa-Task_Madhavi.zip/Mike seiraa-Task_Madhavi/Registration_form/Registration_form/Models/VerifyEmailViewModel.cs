﻿using System.ComponentModel.DataAnnotations;

namespace Registration_form.Models
{
    public class VerifyEmailViewModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string OTP { get; set; }
    }

}
